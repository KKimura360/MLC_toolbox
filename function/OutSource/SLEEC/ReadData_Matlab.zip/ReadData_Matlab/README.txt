1. run make.m  to complie read_data.cpp 
2. all datasets file set to 'Ldata' folder
3. newReadData.m is my function 

Example)

on small datasets,
data=newReadData('Bibtex')

on large datasets, also

data=newReadData('rcv1x');


Have fun;
