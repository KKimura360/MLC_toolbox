function  Dataset=newReadData(filename)
%% Input filename
% dataset must be in the Folder Ldata/

%% Output Dataset (structure data)
%%NOTE
% for bibtex, mediamill and Delicious, filename must be
% 'Bibtex','Mediamill' and 'Delicious', the first letter must be upper one.

if exist(['Ldata/',dataset,'_train'])
data=readData(['Ldata/',dataset]);
numFold=1;
Dataset.train_data=data.X;
Dataset.test_data=data.Xt;
Dataset.train_target=data.Y;
Dataset.test_target=data.Yt;
clear data;
elseif exist(['Ldata/',dataset,'_data.txt'])
    [datamat, labelmat]=read_data(['Ldata/',dataset,'_data.txt']);
    Dataset.datamat=datamat';
    Dataset.labelmat=labelmat';
    Dataset.trind=dlmread(['Ldata/',lower(dataset),'_trSplit.txt'],' ',0,0);
    Dataset.tstind=dlmread(['Ldata/',lower(dataset),'_tstSplit.txt'],' ',0,0);
clear datamat labelmat;
end